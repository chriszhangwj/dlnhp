baseline.py contains the original codes as were given in the beginning of the coursework

improved.py contains the improvement techniques mentioned and not mentioned in the report). They are:
1) Variants of U-Net for the denoising network.
2) DSSIM loss and PSNR loss for the denoising network.
3) Margin ranking loss, margin ranking loss with HNM, ratio loss, ratio loss with HNM, hardnet loss for the descriptor network.

read_data contains the original implementations of data reading with data augmentation added. It shall replace the original read_data in the baseline repository.
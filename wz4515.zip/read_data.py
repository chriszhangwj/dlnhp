## Modification from original HardNet implementation in 
## https://raw.githubusercontent.com/DagnyT/hardnet/master/code/dataloaders/HPatchesDatasetCreator.py
## I need to clean it a little bit and modify some things, but it works

import os
import numpy as np
import cv2
import sys
import json
import keras
from tqdm import tqdm
import glob
import random

splits = ['a', 'b', 'c', 'view', 'illum']
tps = ['ref','e1','e2','e3','e4','e5','h1','h2','h3','h4','h5',\
       't1','t2','t3','t4','t5']

class DenoiseHPatches(keras.utils.Sequence):
    """Class for loading an HPatches sequence from a sequence folder"""
    itr = tps
    def __init__(self, seqs, batch_size = 32):
        self.all_paths = []
        self.batch_size = batch_size
        self.dim = (32, 32)
        self.n_channels = 1
        self.sequences = {}
        self.sequences_n = {}
        for base in tqdm(seqs):
            name = base.split('/')
            self.name = name[-1]
            self.base = base
            for t in self.itr:
                im_path = os.path.join(base, t + '.png')
                img_n = cv2.imread(im_path.replace('.png', '_noise.png'), 0)
                img = cv2.imread(im_path, 0)
                N = img.shape[0] / 32
                seq_im = np.array(np.split(img, N),
                                  dtype=np.uint8)
                seq_im_n = np.array(np.split(img_n, N),
                                    dtype=np.uint8)
                for i in range(int(N)):
                    path = os.path.join(base, t, str(i) + '.png')
                    self.all_paths.append(path)
                    self.sequences[path] = seq_im[i]
                    self.sequences_n[path] = seq_im_n[i]
        self.on_epoch_end()

    def get_images(self, index):
        path = self.all_paths[index]
        img = self.sequences[path].astype(np.float32)
        img_n = self.sequences_n[path].astype(np.float32)
        return img, img_n

    def __len__(self):
        '''Denotes the number of batches per epoch'''
        return int(np.floor(len(self.all_paths) / self.batch_size))

    def __getitem__(self, index):
        img_clean = np.empty((self.batch_size,) + self.dim + (self.n_channels,))
        img_noise = np.empty((self.batch_size,) + self.dim + (self.n_channels,))

        for i in range(self.batch_size):
            img, img_n = self.get_images(index*self.batch_size+i)    
            img_clean[i] = np.expand_dims(img, -1)
            img_noise[i] = np.expand_dims(img_n, -1)

        return img_noise, img_clean    

    def on_epoch_end(self):
        # 'Updates indexes after each epoch'
        random.shuffle(self.all_paths)

class hpatches_sequence_folder:
    """Class for loading an HPatches sequence from a sequence folder"""
    itr = tps
    def __init__(self, base, noise=1):
        name = base.split('/')
        self.name = name[-1]
        self.base = base
        if noise:
            noise_path = '_noise'
        else:
            noise_path = ''
        for t in self.itr:
            im_path = os.path.join(base, t+noise_path+'.png')
            im = cv2.imread(im_path,0)
            self.N = im.shape[0]/32
            setattr(self, t, np.split(im, self.N))



def generate_triplets(labels, num_triplets, batch_size, random_sampling=True): # pass in all labels, batch size is fixed to be 32
    def create_indices(_labels):
        inds = dict() #
        for idx, ind in enumerate(_labels):
            if ind not in inds: # if ind is not in inds
                inds[ind] = [] # clear ind of inds
            inds[ind].append(idx) # append idx at location ind of inds
        return inds
    
    triplets = []
    indices = create_indices(np.asarray(labels)) # convert labels from list to array
    unique_labels = np.unique(np.asarray(labels)) # find uniaue labels
    n_classes = unique_labels.shape[0] # count number of unique labels
    # add only unique indices in batch
    already_idxs = set()    
    for x in tqdm(range(num_triplets)): # loop num_triplets times
        if len(already_idxs) >= batch_size: # for batch size 32, make sure already_idx does not exceed this length
            already_idxs = set() # already_idxs is used to ensure diversity of anchor sample in each batch of 32 samples
        c1 = np.random.randint(0, n_classes) # randomly pick a class label
        while c1 in already_idxs: # if c1 already in already_idxs, keep picking until find one that is not in already_idxs yet
            c1 = np.random.randint(0, n_classes)
        already_idxs.add(c1) # put a new c1 in already_idxs
        c2 = np.random.randint(0, n_classes) # randomly pick a class label
        while c1 == c2: # if c1 and c2 are the same, keep picking c2
            c2 = np.random.randint(0, n_classes)
        if len(indices[c1]) == 2:  # hack to speed up process # if class c1 only has 2 samples in the entire label pool
            n1, n2 = 0, 1 # then n1 and n2 are 0 and 1 respectively
        else:
            n1 = np.random.randint(0, len(indices[c1])) # pick an n1 of class c1
            n2 = np.random.randint(0, len(indices[c1])) # pick an n2 of class c1
            while n1 == n2: # make sure n1 and n2 are not the same one
                n2 = np.random.randint(0, len(indices[c1])) # if same, keep picking n2 until n2 is a different one
        n3 = np.random.randint(0, len(indices[c2])) # pick n3 from class c2. n3 is the negative sample
        triplets.append([indices[c1][n1], indices[c1][n2], indices[c2][n3]]) # n1, n2, n3 are a, p, n in order
        # indices: row: class; column: within-class sample index
    return np.array(triplets)


class HPatches():
    def __init__(self, train=True, transform=None, download=False, train_fnames=[],
                 test_fnames=[], denoise_model=None, use_clean=False):
        self.train = train
        self.transform = transform
        self.train_fnames = train_fnames
        self.test_fnames = test_fnames
        self.denoise_model = denoise_model
        self.use_clean = use_clean

    def set_denoise_model(self, denoise_model):
        self.denoise_model = denoise_model

    def denoise_patches(self, patches):
        batch_size = 100
        for i in tqdm(range(int(len(patches) / batch_size)), file=sys.stdout):
            batch = patches[i * batch_size:(i + 1) * batch_size]
            batch = np.expand_dims(batch, -1)
            batch = np.clip(self.denoise_model.predict(batch).astype(int),
                                        0, 255).astype(np.uint8)[:,:,:,0]
            patches[i*batch_size:(i+1)*batch_size] = batch
        batch = patches[i*batch_size:]
        batch = np.expand_dims(batch, -1)
        batch = np.clip(self.denoise_model.predict(batch).astype(int),
                        0, 255).astype(np.uint8)[:,:,:,0]
        patches[i*batch_size:] = batch
        return patches

    def read_image_file(self, data_dir, train = 1):
        """Return a Tensor containing the patches
        """
        if self.denoise_model and not self.use_clean:
            print('Using denoised patches')
        elif not self.denoise_model and not self.use_clean:
            print('Using noisy patches')
        elif self.use_clean:
            print('Using clean patches')
        sys.stdout.flush()
        patches = []
        labels = []
        counter = 0
        hpatches_sequences = [x[1] for x in os.walk(data_dir)][0]
        if train:
            list_dirs = self.train_fnames 
        else:
            list_dirs = self.test_fnames 

        for directory in tqdm(hpatches_sequences, file=sys.stdout):
           if (directory in list_dirs): # only go into folders used for either training or testing
            for tp in tps:# tps is the type of sequences; loop through all files in folder
                if self.use_clean: # if use clean
                    sequence_path = os.path.join(data_dir, directory, tp)+'.png'
                else: # if use denoised
                    sequence_path = os.path.join(data_dir, directory, tp)+'_noise.png'
                image = cv2.imread(sequence_path, 0)
                h, w = image.shape # get shape of long picture
                n_patches = int(h / w) # find number of patches contained in the picture
                for i in range(n_patches): # for each patch
                    patch = image[i * (w): (i + 1) * (w), 0:w] # extract this single patch from long picture
                    patch = cv2.resize(patch, (32, 32))
                    patch = np.array(patch, dtype=np.uint8)
                    patches.append(patch) # append single patch
                    labels.append(i + counter) # use counter as the label
            counter += n_patches # for each tp. set new label

        patches = np.array(patches, dtype=np.uint8) # this patches variable stores all selected patches for training or testing
        if self.denoise_model and not self.use_clean:
            print('Denoising patches...')
            patches = self.denoise_patches(patches)
        return patches, labels


class DataGeneratorDesc(keras.utils.Sequence):
    # 'Generates data for Keras'
    def __init__(self, data, labels, num_triplets = 1000000, batch_size=50, dim=(32,32), n_channels=1, shuffle=True):
        # 'Initialization'
        self.transform = None
        self.out_triplets = True
        self.dim = dim
        self.batch_size = batch_size
        self.n_channels = n_channels
        self.shuffle = shuffle
        self.data = data # data is all patches
        self.labels = labels # labels is all corresponding labels
        self.num_triplets = num_triplets
        self.on_epoch_end()

    def get_image(self, t): # t is one triplet
        def transform_img(img):
            if self.transform is not None:
                img = transform(img.numpy())
            return img

        a, p, n = self.data[t[0]], self.data[t[1]], self.data[t[2]] # t contains many triples of a, p, n in order

        img_a = transform_img(a).astype(float)
        img_p = transform_img(p).astype(float)
        img_n = transform_img(n).astype(float)
        
        if fliprot == True:
            do_flip = random.random() > 0.5
            do>rot = random.random() > 0.5
            if do_rot:
                img_a = img_a.permute(0,2,1)
                img_p = img_p.permute(0,2,1)
                if self.out_triplets:
                    img_n = img_n.permute(0,2,1)
            if do_flip:
                img_a = torch.from_numpy(deepcopy(img_a.numpy()[:,:,::-1]))
                img_p = torch.from_numpy(deepcopy(img_p.numpy()[:,:,::-1]))
                if self.out_triplets:
                    img_n = torch.from_numpy(deepcopy(img_n.numpy()[:,:,::-1]))
        
        img_a = np.expand_dims(img_a, -1)
        img_p = np.expand_dims(img_p, -1)
        img_n = np.expand_dims(img_n, -1)
        if self.out_triplets:
            return img_a, img_p, img_n
        else:
            return img_a, img_p

    def __len__(self):
        '''Denotes the number of batches per epoch'''
        return int(np.floor(len(self.triplets) / self.batch_size)) # total number of triplets/batch_size
                
    def __getitem__(self, index): # select triplets a,p,n from all data, for each batch
        y = np.zeros((self.batch_size, 1)) # initialise y to be batch size * 1 (for batch labels)
        img_a = np.empty((self.batch_size,) + self.dim + (self.n_channels,))
        img_p = np.empty((self.batch_size,) + self.dim + (self.n_channels,))
        if self.out_triplets: # if out_triplets is true, prepare also negative
            img_n = np.empty((self.batch_size,) + self.dim + (self.n_channels,))
        for i in range(self.batch_size): # for 1:batch size
            t = self.triplets[self.batch_size*index + i] # get a new triplet index   
            img_a_t, img_p_t, img_n_t = self.get_image(t) # t is the current triplet index
            img_a[i] = img_a_t
            img_p[i] = img_p_t
            if self.out_triplets:
                img_n[i] = img_n_t

        return {'a': img_a, 'p': img_p, 'n': img_n}, y

    def on_epoch_end(self):
        # 'Updates indexes after each epoch'
        self.triplets = generate_triplets(self.labels, self.num_triplets, 32)

    
    
